from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'strtup'

mysql = MySQL(app)

@app.route("/")
def index():
    return render_template("first.html")

@app.route("/reg", methods = ['GET', 'POST'])
def reg():
    if request.method =='POST':
        username = request.form['email']
        password = request.form['pass']
        name = request.form['name']
        age = request.form['age']
        mobile = request.form['mobile']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO docreg VALUES ("%s","%s","%s","%s","%s")'% (name, username, mobile, age, password))
        mysql.connection.commit()
        #msg = "Sucessful Please go to home."
    
    return render_template("reg.html" )

@app.route("/log", methods = ['GET', 'POST'])
def log():
    if request.method =='POST':
        username = request.form['email']
        password = request.form['pass']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM docreg WHERE email = %s AND pass = %s', (username, password))
        account = cursor.fetchone()
        if account:
            #session['username'] = account['username']
            return render_template("index.html")
    return render_template("log.html")

@app.route("/fill", methods = ['GET', 'POST'])
def fill():
    if request.method =='POST':
        name = request.form['name']
        sol = request.form['sol']
        desc = request.form['desc']
        user = ""

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO form(`name`, `desc`, `sol`,`user`) VALUES ("%s","%s","%s","%s")'% (name, desc, sol, user))
        mysql.connection.commit()
        
        return render_template("index.html")
    
    return render_template("fill.html")

if __name__ == '__main__':
    app.run(debug=True)